from django.shortcuts import render
from django.http import HttpResponse
from .models import Cancha
from .models import Persona

# Create your views here.

def getInfoCanchaById (request, id_cancha):
    #Obtener cancha por su id utilizando ORM
    cancha = Cancha.objects.get(id=id_cancha)
    result = f"Cancha: {cancha.nombre}, Descripción: {cancha.descripcion}"
    return HttpResponse(result)

def getPersonaById (request, id_persona):
    #Obtener persona por su id utilizando ORM
    persona = Persona.objects.get(id=id_persona)
    result = f"Nombre: {persona.nombre}, Apellido: {persona.apellido}, Correo: {persona.correo}"
    return HttpResponse(result)
